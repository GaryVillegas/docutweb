import styles from "./Citas.module.css";
import React, { useState, useEffect } from "react";
import { MenuLateral } from "../../../components/MenuLateral";
import { Link } from "react-router-dom";

export const Citas = () => {
  const [citas, ] = useState([
    // Ejemplo de datos (después los puedes traer de Firebase)
    {
      cliente: "Juan Pérez",
      fecha: "2025-06-08",
      hora: "10:00",
      servicio: "Corte",
      estado: "Pendiente"
    },
    {
      cliente: "María López",
      fecha: "2025-06-08",
      hora: "11:00",
      servicio: "Corte",
      estado: "pendiente"
    }
  ]);

  return (
    <div className={styles.layout}>
      <MenuLateral />

      <main className={styles.main}>
        <h1 className={styles.title}>Citas Programadas</h1>
        <div className={styles.content}>
          {citas.length === 0 ? (
            <p>No hay citas programadas.</p>
          ) : (
            <table className={styles.table}>
              <thead>
                <tr>
                  <th>Cliente</th>
                  <th>Fecha</th>
                  <th>Hora</th>
                  <th>Servicio</th>
                  <th>Estado</th>
                </tr>
              </thead>
              <tbody>
                {citas.map((cita, index) => (
                  <tr key={index}>
                    <td>{cita.cliente}</td>
                    <td>{cita.fecha}</td>
                    <td>{cita.hora}</td>
                    <td>{cita.servicio}</td>
                    <td>{cita.estado}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </main>
    </div>
  );
};
