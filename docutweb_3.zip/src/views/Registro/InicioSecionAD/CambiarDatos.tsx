import styles from "./CambiarDatos.module.css";
import React, { useState } from "react";
import { MenuLateral } from "../../../components/MenuLateral";

export const CambiarDatos = () => {
  const [modoEdicion, setModoEdicion] = useState(false);
  const [formulario, setFormulario] = useState({
    nombre: "josmi",
    apellido: "coloma",
    correo: "joms.coloma",
    rut: "22222222222",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormulario({ ...formulario, [e.target.name]: e.target.value });
  };

  const guardarCambios = () => {
    setModoEdicion(false);
    alert("Datos actualizados correctamente");
  };

  return (
    <div className={styles.layout}>
      {/* Sidebar */}
       <MenuLateral />
       
      {/* Contenido principal */}
      <main className={styles.main}>
        
        <div className={styles.content}>
            <h1 className={styles.title}>Datos de usuario</h1>
         {!modoEdicion ? (
  <div className={styles.userDataBox}>
    <h2>Información actual</h2>
    <ul className={styles.userData}>
      <li><strong>Nombre:</strong> {formulario.nombre}</li>
      <li><strong>Apellido:</strong> {formulario.apellido}</li>
      <li><strong>Correo:</strong> {formulario.correo}</li>
      <li><strong>RUT:</strong> {formulario.rut}</li>
    </ul>
    <button className={styles.button} onClick={() => setModoEdicion(true)}>
      Actualizar
    </button>
  </div>
) : (
  <form className={styles.form} onSubmit={(e) => { e.preventDefault(); guardarCambios(); }}>
    <label>
      Nombre:
      <input type="text" name="nombre" value={formulario.nombre} autoComplete="off" onChange={handleChange} />
    </label>
    <label>
      Apellido:
      <input type="text" name="apellido" value={formulario.apellido} onChange={handleChange} />
    </label>
    <label>
      Correo:
      <input type="email" name="correo" value={formulario.correo} onChange={handleChange} />
    </label>
    <label>
      RUT:
      <input
  type="text"
  name="rut"
  value="21.000.000-0"
  readOnly
  style={{ backgroundColor: "#f9f9f9", cursor: "not-allowed" }}
/>

    </label>
    <button type="submit" className={styles.button}>Guardar cambios</button>
  </form>
)}

        </div>
      </main>
    </div>
  );
};
