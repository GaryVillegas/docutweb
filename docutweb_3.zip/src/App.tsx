import "./App.css";
import { AppRouter } from "./router/AppRouter";
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
  return (
    <>
      <AppRouter />
    </>
  );
}

export default App;
